'use strict';

// init
require('./init/init.js');