'use strict';

// window open index
exports.windowOpenIndex = require('./index-window.js');