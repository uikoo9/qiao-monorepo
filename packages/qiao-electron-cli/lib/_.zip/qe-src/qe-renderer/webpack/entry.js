'use strict';

// path
var path = require('path');

// entry path
var indexPath = path.resolve(__dirname, '../src/views/index-view.js');

// entry
module.exports = {
  index: indexPath,
};