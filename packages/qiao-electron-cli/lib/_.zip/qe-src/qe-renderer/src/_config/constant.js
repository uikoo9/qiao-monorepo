'use strict';

/**
 * constant
 */