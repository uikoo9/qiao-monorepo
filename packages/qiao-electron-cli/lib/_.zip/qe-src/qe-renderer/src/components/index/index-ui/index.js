'use strict';

// react
import React from 'react';

// index
import 'normalize.css';
import './index.scss';

/**
 * index component
 */
export default class IndexComponent extends React.Component {
  render() {
    return (
      <div className='index-container'>
      </div>
    );
  }
}