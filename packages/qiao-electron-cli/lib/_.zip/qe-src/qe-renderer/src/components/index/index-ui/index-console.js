'use strict';

// react
import React from 'react';

// index constant
import { IndexConstant } from '../_constant.js';

/**
 * index console
 */
export default class IndexConsole extends React.Component {
    render() {
        return (
            <div className='index-console'>
            </div>
        );
    }
}