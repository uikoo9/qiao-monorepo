/*Table structure for table `t_ucenter_code` */

DROP TABLE IF EXISTS `t_ucenter_code`;

CREATE TABLE `t_ucenter_code` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `ucenter_code_type` varchar(10) NOT NULL COMMENT '验证码类型',
  `ucenter_code_mobile` varchar(200) NOT NULL COMMENT '验证码手机号',
  `ucenter_code_code` char(6) NOT NULL COMMENT '验证码',
  `cdate` datetime NOT NULL COMMENT '创建时间',
  `cuser_id` int(10) NOT NULL COMMENT '创建人id',
  `cuser_name` varchar(200) NOT NULL COMMENT '创建人姓名',
  `udate` datetime NOT NULL COMMENT '更新时间',
  `uuser_id` int(10) NOT NULL COMMENT '更新人id',
  `uuser_name` varchar(200) NOT NULL COMMENT '更新人姓名',
  `del_tag` char(1) NOT NULL COMMENT '是否删除，0否，1是',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

/*Data for the table `t_ucenter_code` */

/*Table structure for table `t_ucenter_menu` */

DROP TABLE IF EXISTS `t_ucenter_menu`;

CREATE TABLE `t_ucenter_menu` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `ucenter_menu_parent` int(10) NOT NULL COMMENT '菜单父id',
  `ucenter_menu_sn` char(3) NOT NULL COMMENT '菜单序号',
  `ucenter_menu_title` varchar(200) NOT NULL COMMENT '菜单名称',
  `ucenter_menu_url` varchar(200) NOT NULL COMMENT '菜单地址',
  `cdate` datetime NOT NULL COMMENT '创建时间',
  `cuser_id` int(10) NOT NULL COMMENT '创建人id',
  `cuser_name` varchar(200) NOT NULL COMMENT '创建人姓名',
  `udate` datetime NOT NULL COMMENT '更新时间',
  `uuser_id` int(10) NOT NULL COMMENT '更新人id',
  `uuser_name` varchar(200) NOT NULL COMMENT '更新人姓名',
  `del_tag` char(1) NOT NULL COMMENT '是否删除，0否，1是',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

/*Data for the table `t_ucenter_menu` */

insert  into `t_ucenter_menu`(`id`,`ucenter_menu_parent`,`ucenter_menu_sn`,`ucenter_menu_title`,`ucenter_menu_url`,`cdate`,`cuser_id`,`cuser_name`,`udate`,`uuser_id`,`uuser_name`,`del_tag`) values (22,0,'01','权限模块','--','2019-03-07 17:51:54',1,'admin','2019-03-07 17:51:54',1,'admin','0'),(23,22,'01','菜单管理','./ucenter/ucenter-menu.js','2019-03-07 17:52:04',1,'admin','2019-03-07 17:52:38',1,'admin','0'),(24,22,'02','角色管理','./ucenter/ucenter-role.js','2019-03-07 17:52:12',1,'admin','2019-03-07 17:53:01',1,'admin','0'),(25,22,'03','角色菜单管理','./ucenter/ucenter-role-r-menu.js','2019-03-07 17:52:18',1,'admin','2019-03-07 17:53:13',1,'admin','0'),(26,22,'04','角色用户管理','./ucenter/ucenter-role-r-user.js','2019-03-07 17:52:25',1,'admin','2019-03-07 17:53:24',1,'admin','0');

/*Table structure for table `t_ucenter_role` */

DROP TABLE IF EXISTS `t_ucenter_role`;

CREATE TABLE `t_ucenter_role` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `ucenter_role_name` varchar(200) NOT NULL COMMENT '角色名称',
  `ucenter_role_url` varchar(200) NOT NULL COMMENT '角色跳转地址',
  `cdate` datetime NOT NULL COMMENT '创建时间',
  `cuser_id` int(10) NOT NULL COMMENT '创建人id',
  `cuser_name` varchar(200) NOT NULL COMMENT '创建人姓名',
  `udate` datetime NOT NULL COMMENT '更新时间',
  `uuser_id` int(10) NOT NULL COMMENT '更新人id',
  `uuser_name` varchar(200) NOT NULL COMMENT '更新人姓名',
  `del_tag` char(1) NOT NULL COMMENT '是否删除，0否，1是',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

/*Data for the table `t_ucenter_role` */

insert  into `t_ucenter_role`(`id`,`ucenter_role_name`,`ucenter_role_url`,`cdate`,`cuser_id`,`cuser_name`,`udate`,`uuser_id`,`uuser_name`,`del_tag`) values (3,'超级管理员','/login','2019-03-06 19:47:24',1,'admin','2019-03-07 18:15:51',1,'admin','0'),(5,'管理员','/login','2019-03-07 18:20:16',1,'admin','2019-03-07 18:20:16',1,'admin','0');

/*Table structure for table `t_ucenter_role_r_menu` */

DROP TABLE IF EXISTS `t_ucenter_role_r_menu`;

CREATE TABLE `t_ucenter_role_r_menu` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `ucenter_role_id` int(10) NOT NULL COMMENT '角色id',
  `ucenter_menu_id` int(10) NOT NULL COMMENT '菜单id',
  `cdate` datetime NOT NULL COMMENT '创建时间',
  `cuser_id` int(10) NOT NULL COMMENT '创建人id',
  `cuser_name` varchar(200) NOT NULL COMMENT '创建人姓名',
  `udate` datetime NOT NULL COMMENT '更新时间',
  `uuser_id` int(10) NOT NULL COMMENT '更新人id',
  `uuser_name` varchar(200) NOT NULL COMMENT '更新人姓名',
  `del_tag` char(1) NOT NULL COMMENT '是否删除，0否，1是',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;

/*Data for the table `t_ucenter_role_r_menu` */

insert  into `t_ucenter_role_r_menu`(`id`,`ucenter_role_id`,`ucenter_menu_id`,`cdate`,`cuser_id`,`cuser_name`,`udate`,`uuser_id`,`uuser_name`,`del_tag`) values (16,3,22,'2019-03-07 17:59:16',1,'admin','2019-03-07 17:59:16',1,'admin','0'),(17,3,23,'2019-03-07 17:59:16',1,'admin','2019-03-07 17:59:16',1,'admin','0'),(18,3,24,'2019-03-07 17:59:16',1,'admin','2019-03-07 17:59:16',1,'admin','0'),(19,3,25,'2019-03-07 17:59:16',1,'admin','2019-03-07 17:59:16',1,'admin','0'),(20,3,26,'2019-03-07 17:59:16',1,'admin','2019-03-07 17:59:16',1,'admin','0');

/*Table structure for table `t_ucenter_role_r_user` */

DROP TABLE IF EXISTS `t_ucenter_role_r_user`;

CREATE TABLE `t_ucenter_role_r_user` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `ucenter_role_id` int(10) NOT NULL COMMENT '角色id',
  `ucenter_user_id` int(10) NOT NULL COMMENT '用户id',
  `cdate` datetime NOT NULL COMMENT '创建时间',
  `cuser_id` int(10) NOT NULL COMMENT '创建人id',
  `cuser_name` varchar(200) NOT NULL COMMENT '创建人姓名',
  `udate` datetime NOT NULL COMMENT '更新时间',
  `uuser_id` int(10) NOT NULL COMMENT '更新人id',
  `uuser_name` varchar(200) NOT NULL COMMENT '更新人姓名',
  `del_tag` char(1) NOT NULL COMMENT '是否删除，0否，1是',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/*Data for the table `t_ucenter_role_r_user` */

insert  into `t_ucenter_role_r_user`(`id`,`ucenter_role_id`,`ucenter_user_id`,`cdate`,`cuser_id`,`cuser_name`,`udate`,`uuser_id`,`uuser_name`,`del_tag`) values (1,3,1,'2019-03-07 17:57:12',1,'admin','2019-03-07 17:57:12',1,'admin','0'),(2,5,25,'2019-03-07 18:28:47',1,'admin','2019-03-07 18:28:47',1,'admin','0');

/*Table structure for table `t_ucenter_user` */

DROP TABLE IF EXISTS `t_ucenter_user`;

CREATE TABLE `t_ucenter_user` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `ucenter_user_name` varchar(200) NOT NULL COMMENT '用户名',
  `ucenter_user_password` varchar(200) NOT NULL COMMENT '用户密码',
  `cdate` datetime NOT NULL COMMENT '创建时间',
  `cuser_id` int(10) NOT NULL COMMENT '创建人id',
  `cuser_name` varchar(200) NOT NULL COMMENT '创建人姓名',
  `udate` datetime NOT NULL COMMENT '更新时间',
  `uuser_id` int(10) NOT NULL COMMENT '更新人id',
  `uuser_name` varchar(200) NOT NULL COMMENT '更新人姓名',
  `del_tag` char(1) NOT NULL COMMENT '是否删除，0否，1是',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;

/*Data for the table `t_ucenter_user` */

insert  into `t_ucenter_user`(`id`,`ucenter_user_name`,`ucenter_user_password`,`cdate`,`cuser_id`,`cuser_name`,`udate`,`uuser_id`,`uuser_name`,`del_tag`) values (1,'admin','yqLMGkjcEnJW2GJRys5mOQ==','2018-11-13 19:57:04',1,'admin','2018-11-13 19:57:10',1,'admin','0'),(25,'18612257325','EbpR3wnqj2B0YD7flSCD/Q==','2018-12-19 17:05:07',1,'admin','2018-12-19 17:05:12',1,'admin','0');

